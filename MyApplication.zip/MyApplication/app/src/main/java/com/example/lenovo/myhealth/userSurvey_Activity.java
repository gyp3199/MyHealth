package com.example.lenovo.myhealth;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class userSurvey_Activity extends AppCompatActivity {

    //layout
    private CheckBox ch;
    private Button btn;
    private String count;
    private String uid;

    //toolbar
    private Toolbar toolbar;

    //firebase
    private FirebaseAuth auth;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_survey_);

        //layout
        ch = findViewById(R.id.s_check);
        btn = findViewById(R.id.test);

        uid = getIntent().getStringExtra("uid");


        final String area = getIntent().getStringExtra("area");





        //firebase
        databaseReference = FirebaseDatabase.getInstance().getReference().child("Survey").child(area);


        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                count = dataSnapshot.child("count").getValue().toString();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(userSurvey_Activity.this,count,Toast.LENGTH_SHORT).show();

                if(ch.isChecked()){

                    int cc = Integer.valueOf(count);

                    cc += 1;

                    databaseReference.child("count").setValue(String.valueOf(cc));

                    Toast.makeText(userSurvey_Activity.this,area,Toast.LENGTH_SHORT).show();

                    Intent u = new Intent(userSurvey_Activity.this,responseReceived_Activity.class);
                    u.putExtra("uid",uid);
                    startActivity(u);
                    finish();

                }



            }
        });

    }
}
