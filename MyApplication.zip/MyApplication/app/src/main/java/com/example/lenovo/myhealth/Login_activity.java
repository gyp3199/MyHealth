package com.example.lenovo.myhealth;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Login_activity extends AppCompatActivity {

    //layout
    private EditText mail;
    private EditText password;
    private Button login;


    //toolbar
    private Toolbar toolbar;

    //firebase
    private FirebaseAuth mAuth;
    private DatabaseReference databaseReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_activity);

        //layout
        mail = findViewById(R.id.login_mail);
        password = findViewById(R.id.login_password);
        login = findViewById(R.id.login_btn);



        //firebase
        mAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference();



        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String pmail = mail.getText().toString();
                String pass = password.getText().toString();

                if(!TextUtils.isEmpty(pass) && !TextUtils.isEmpty(pmail)){

                    doLogin(pmail,pass);

                }


            }
        });
    }

    private void doLogin(String pmail, String pass) {

        mAuth.signInWithEmailAndPassword(pmail, pass)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information



                            FirebaseUser user = mAuth.getCurrentUser();

                            String uid = user.getUid();

                            databaseReference = FirebaseDatabase.getInstance().getReference().child("Users").child(uid);

                            databaseReference.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                    Boolean ngo = Boolean.valueOf(dataSnapshot.child("NGO").getValue().toString());

                                    String Area = dataSnapshot.child("area").getValue().toString();


                                    if(ngo){

                                        Toast.makeText(Login_activity.this,"logged in !",Toast.LENGTH_SHORT).show();

                                        Intent main1 = new Intent(Login_activity.this,ngo_activity.class);
                                        main1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                        startActivity(main1);
                                        finish();

                                    }
                                    else{

                                        Toast.makeText(Login_activity.this,"logged in !",Toast.LENGTH_LONG).show();

                                        Intent main2 = new Intent(Login_activity.this,User_activity.class);
                                        main2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                        main2.putExtra("Area",Area);
                                        startActivity(main2);

                                        finish();

                                    }

                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });




                          /*  Intent p = new Intent(Login_activity.this,MainActivity.class);
                            p.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(p);
                            finish();*/


                        } else {
                            // If sign in fails, display a message to the user.

                            Toast.makeText(Login_activity.this, "Login failed !",
                                    Toast.LENGTH_SHORT).show();

                        }

                        // ...
                    }
                });



    }
}
