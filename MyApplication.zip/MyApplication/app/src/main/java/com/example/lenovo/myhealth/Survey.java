package com.example.lenovo.myhealth;

public class Survey {

    public String name;
    public String area;

    public Survey(String name, String area) {
        this.name = name;
        this.area = area;
    }

    public Survey(){}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }
}
