package com.example.lenovo.myhealth;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Survey_Activity extends AppCompatActivity {

    private RecyclerView surveyList;

    //firebase
    private DatabaseReference databaseReference;

    //toolbar
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survey_);



        surveyList = findViewById(R.id.surveylist);
        surveyList.setHasFixedSize(true);
        surveyList.setLayoutManager(new LinearLayoutManager(this));

        databaseReference = FirebaseDatabase.getInstance().getReference().child("Users");
    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseRecyclerOptions<Survey> options = new FirebaseRecyclerOptions.Builder<Survey>().setQuery(databaseReference,Survey.class).build();

        FirebaseRecyclerAdapter<Survey,surveyViewHolder> firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<Survey,surveyViewHolder>(options) {

            @Override
            protected void onBindViewHolder(@NonNull surveyViewHolder holder, int position, @NonNull Survey model) {


                holder.setName(model.getName());
                holder.setArea(model.getArea());

            }

            @NonNull
            @Override
            public surveyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

                View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.area_layout,viewGroup,false);

                return new surveyViewHolder(view);
            }
        };

        firebaseRecyclerAdapter.startListening();
        surveyList.setAdapter(firebaseRecyclerAdapter);


    }


    public   class surveyViewHolder extends RecyclerView.ViewHolder {

        View pview;

        public surveyViewHolder(@NonNull View itemView) {
            super(itemView);

            pview = itemView;

        }

        public void setName(String name) {

            TextView aa = pview.findViewById(R.id.survey_name);
            aa.setText(name);
        }

        public void setArea(String area) {

            TextView pp = pview.findViewById(R.id.survey_area);
            pp.setText(area);

        }


    }
}
